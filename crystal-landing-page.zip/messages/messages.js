import en from './en.json';
import ar from './ar.json';

const messages = {
  en,
  ar,
};

export default messages;