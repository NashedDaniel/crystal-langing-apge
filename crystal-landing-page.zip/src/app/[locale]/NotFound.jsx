'use client';

export default function NotFound() {
  return (
    <html>
      <body className='text-center'>
        <h1 className='mt-10 font-semibold'>Something went wrong!</h1>
      </body>
    </html>
  );
}